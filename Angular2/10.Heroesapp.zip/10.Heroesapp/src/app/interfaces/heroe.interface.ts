export interface Heroe {
  nombre: string;
  bio: string;
  casa: string;
  key$?: string;
}
